from flask import*

from src.Predictionile import *
from src.dbconnectionnew import *

obj = Flask(__name__)
obj.secret_key="999"
import functools

def login_required(func):
    @functools.wraps(func)
    def secure_function():
        if "lid" not in session:
            return redirect('/')
        return func()

    return secure_function

@obj.route('/logout')
def logout():
    return redirect('/')

@obj.route('/')
def main():
    return render_template('admin/LOGIN.html')

@obj.route('/login_code', methods = ['post'])
def login_code():
    u_name = request.form['textfield']
    password = request.form['textfield2']
    query = "select * from login WHERE uname = %s AND pswd = %s"
    value = (u_name, password)
    result = selectone(query, value)
    if result is None:
        return ''' <script> alert("Invalid Username or Password"); window.location = "/" </script>'''
    elif result['utype'] == "admin" :
        session['lid']=result['id']
        return ''' <script> alert("Welcome Admin"); window.location = "/admin_home"</script>'''
    elif result['utype'] == "nutritionist":
        session['lid'] = result['id']
        return ''' <script> alert("Welcome Nutritionist"); window.location = "/nut_home"</script>'''
    elif result['utype'] == "user":
        session['lid'] = result['id']
        return ''' <script> alert("Welcome User"); window.location = "/user_home"</script>'''

#=======================================================ADMIN===========================================================

@obj.route('/admin_home')
@login_required
def admin_home():
    return render_template('adminindex.html')

@obj.route('/view_nutritionsit')
@login_required
def view_nutritionsit():
    q="SELECT * FROM nutri"
    res=selectall(q)
    return render_template('admin/view_nutrtionist.html',data=res)

@obj.route('/add_nutritionist',methods=['post'])
@login_required
def add_nutritionist():
    return render_template('admin/add_nutritionist.html')

@obj.route('/add_nutri_post', methods=['POST'])
@login_required
def add_nutri_post():
    fname=request.form['textfield']
    lname=request.form['textfield2']
    place=request.form['textfield3']
    phone=request.form['textfield4']
    email=request.form['textfield5']
    uname=request.form['textfield6']
    psw=request.form['textfield7']

    q="INSERT INTO `login` VALUES (NULL,%s,%s,'nutritionist')"
    val=(uname,psw)
    id=iud(q,val)

    qry="INSERT INTO `nutri` VALUES (NULL,%s,%s,%s,%s,%s,%s)"
    v=(str(id),fname,lname,place,phone,email)
    iud(qry,v)
    return ''' <script> alert("Added successfully"); window.location = "/view_nutritionsit#about"</script>'''

@obj.route('/edit_nutritionist')
@login_required
def edit_nutritionist():
    id=request.args.get('id')
    session['nu_id']=id
    q="SELECT * FROM nutri where lid=%s"
    res=selectone(q,id)
    return render_template('admin/edit_nutritionist.html',data=res)

@obj.route('/edit_nutri_post', methods=['POST'])
@login_required
def edit_nutri_post():
    fname=request.form['textfield']
    lname=request.form['textfield2']
    place=request.form['textfield3']
    phone=request.form['textfield4']
    email=request.form['textfield5']

    qry="UPDATE `nutri` set `fname`=%s,`lname`=%s,`place`=%s,`phone`=%s,`email`=%s where `lid`=%s"
    v=(fname,lname,place,phone,email,session['nu_id'])
    iud(qry,v)
    return ''' <script> alert("Updated successfully"); window.location = "/view_nutritionsit#about"</script>'''

@obj.route('/del_nutritionist')
def del_nutritionist():
    id=request.args.get('id')
    q="delete from nutri where lid=%s"
    iud(q,id)
    qq="delete from login where id=%s"
    iud(qq,id)
    return ''' <script> alert("Deleted successfully"); window.location = "/view_nutritionsit#about"</script>'''

@obj.route('/view_complaint')
@login_required
def view_complaint():
    qry = "SELECT `complaint`.*,`user`.* FROM `complaint` INNER JOIN `user` ON `complaint`.`lid`=`user`.`lid` "
    res=selectall(qry)
    return render_template('admin/view_complaint.html',data=res)

@obj.route('/reply')
@login_required
def reply():
    id=request.args.get('id')
    session['cid']=id
    return render_template('admin/send_reply.html')

@obj.route('/reply_post', methods=['POST'])
def reply_post():
    reply=request.form['textarea']
    q="UPDATE `complaint` SET `reply`=%s WHERE `id`=%s"
    val=(reply,session['cid'])
    iud(q,val)
    return ''' <script> alert("send successfully"); window.location = "/view_complaint#about"</script>'''


# --------------------------nutritionsit--------------------------

@obj.route('/nut_home')
@login_required
def nut_home():
    return render_template('nutr_index.html')

@obj.route('/view_profile')
@login_required
def view_profile():
    q="SELECT * FROM `nutri` WHERE `lid`=%s"
    res=selectone(q,str(session['lid']))
    print(res)
    return render_template('nutritionist/view_profile.html',v=res)

@obj.route('/view_diet')
@login_required
def view_diet():
    q="SELECT * FROM `diet`"
    res=selectall(q)
    return render_template('nutritionist/view_diettip.HTML',data=res)

@obj.route('/add_diet')
@login_required
def add_diet():
    return render_template('nutritionist/add_diet_tips.html')

@obj.route('/add_tip_post', methods=['POST'])
def add_tip_post():
    diet=request.form['textfield']
    tip=request.form['textarea']
    q="INSERT INTO `diet` VALUES (NULL,%s,%s)"
    val=(diet,tip)
    iud(q,val)
    return ''' <script> alert("Add successfully"); window.location = "/view_diet#about"</script>'''

@obj.route('/delete_tip')
def delete_tip():
    id = request.args.get('id')
    q="delete from diet where diet_id=%s"
    iud(q,id)
    return ''' <script> alert("Deleted successfully"); window.location = "/view_diet#about"</script>'''

@obj.route('/view_user')
@login_required
def view_user():
    q="select * from user"
    res=selectall(q)
    return render_template('nutritionist/view_user.HTML',data=res)

#=-==-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-==-=-=--=NUTRI CHAT=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


@obj.route('/chat2',methods=['GET','POST'])
def chat2():
    uid=request.args.get('uid')
    session['nutri_idd']=uid
    print (uid,'++++++++++++++++++++++++++++++++')
    q=" SELECT * FROM `user` WHERE `lid`=%s"
    v=str(uid)
    s1 = selectone(q,v)
    print(s1)
    fid=session['lid']
    session['idd'] = uid
    q=("select * from `chat` where (`fromid`=%s and `toid`=%s) or (`fromid`=%s and `toid`=%s) order by date asc")
    v=(uid,fid,fid,uid)
    s = selectall2(q,v)
    print(s)
    return render_template('nutritionist/chat.html',data=s,fname=s1['fname'],fr=str(uid))

@obj.route('/index1', methods=['POST'])
def index1():
    i=0
    uid = request.form['brand']
    fid = session['lid']
    q=("select * from `chat` where (`fromid`=%s and `toid`=%s) or (`fromid`=%s and `toid`=%s) order by date asc")
    v = uid, fid, fid, uid
    s = selectall2(q, v)
    print(s)
    data=[]
    for i in s:
        if str(i['fromid'])==str(uid):
            data.append(str("1"))
            data.append(str(i['message']))
        else:
            data.append(str("0"))
            data.append(str(i['message']))

    # if(data=='a'):
    #
    #  resp = make_response(json.dumps( ['clt','tsr']))
    # else:
    resp = make_response(jsonify(data))
    resp.status_code = 200
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp

@obj.route('/send1',methods=['GET','POST'])
def send1():
    btn=request.form['button']
    if (btn=="send"):
        fid=session["lid"]
        print(fid)
        tid=session['idd']
        session['uidd']=tid
        print(tid)
        msg=request.form['textarea']
        q="insert into chat values(null,%s,%s,%s,curdate())"
        v=fid,tid,msg
        iud(q,v)
        return "<script>window.location='/chat2?uid="+session['uidd']+"#about'</script>"
    else:
        return  "<script>window.location='/chat2?uid="+session['uidd']+"#about'</script>"


# -----------------------------user----------------------------------------------------

@obj.route('/user_home')
@login_required
def user_home():
    return render_template('user_index.html')

@obj.route('/user_reg')
def user_reg():
    return render_template('user/user_reg.html')

@obj.route('/user_reg_post', methods=['POST'])
@login_required
def user_reg_post():
    fname=request.form['textfield']
    lname=request.form['textfield2']
    place=request.form['textfield3']
    post=request.form['textfield33']
    phone=request.form['textfield4']
    email=request.form['textfield5']
    uname=request.form['textfield6']
    psw=request.form['textfield7']

    q="INSERT INTO `login` VALUES (NULL,%s,%s,'user')"
    val=(uname,psw)
    id=iud(q,val)

    qry="INSERT INTO `user` VALUES (NULL,%s,%s,%s,%s,%s,%s,%s)"
    v=(str(id),fname,lname,place,post,phone,email)
    iud(qry,v)
    return ''' <script> alert("Registration successfully"); window.location = "/#about"</script>'''

@obj.route('/user_view_nutri')
@login_required
def user_view_nutri():
    q="SELECT * FROM `nutri`"
    res=selectall(q)
    return render_template('user/user_view_nutrtionist.html',data=res)

@obj.route('/user_view_diettip')
@login_required
def user_view_diettip():
    q="select * from diet"
    res=selectall(q)
    return render_template('user/user_view_diettip.HTML',data=res)

#=========================================================USER CHAT=====================================================

@obj.route('/chat1',methods=['GET','POST'])
def chat1():
    nutri_idd=request.args.get('uid')
    session['nutri_idd']=nutri_idd
    print (nutri_idd,'++++++++++++++++++++++++++++++++')
    q=" SELECT * FROM `nutri` WHERE `lid`=%s"
    v=str(nutri_idd)
    s1 = selectone(q,v)
    print(s1)
    fid=session['lid']
    session['idd'] = nutri_idd
    q=("select * from `chat` where (`fromid`=%s and `toid`=%s) or (`fromid`=%s and `toid`=%s) order by date asc")
    v=(nutri_idd,fid,fid,nutri_idd)
    s = selectall2(q,v)
    print(s)
    return render_template('user/chat.html',data=s,fname=s1['fname'],fr=str(nutri_idd))

@obj.route('/index', methods=['POST'])
def index():
    i=0
    uid = request.form['brand']
    fid = session['lid']

    q=("select * from `chat` where (`fromid`=%s and `toid`=%s) or (`fromid`=%s and `toid`=%s) order by date asc")
    v = uid, fid, fid, uid
    s = selectall2(q, v)
    print(s)
    data=[]
    for i in s:
        if str(i['fromid'])==str(uid):
            data.append(str("1"))
            data.append(str(i['message']))
        else:
            data.append(str("0"))
            data.append(str(i['message']))

    # if(data=='a'):
    #
    #  resp = make_response(json.dumps( ['clt','tsr']))
    # else:
    resp = make_response(jsonify(data))
    resp.status_code = 200
    resp.headers['Access-Control-Allow-Origin'] = '*'
    return resp

@obj.route('/send',methods=['GET','POST'])
def send():
    btn=request.form['button']
    if (btn=="send"):
        fid=session["lid"]
        print(fid)
        tid=session['idd']
        session['uidd']=tid
        print(tid)
        msg=request.form['textarea']
        q="insert into chat values(null,%s,%s,%s,curdate())"
        v=fid,tid,msg
        iud(q,v)
        return "<script>window.location='/chat1?uid="+session['uidd']+"#about'</script>"
    else:
        return  "<script>window.location='/chat1?uid="+session['uidd']+"#about'</script>"

@obj.route('/predict_heart')
def predict_heart():

    return render_template('user/predict.html')

@obj.route('/predict_post', methods=['POST'])
def predict_post():
    age = request.form['textfield']
    Gender = request.form['radiobutton1']
    cp = request.form['select']
    rbp = request.form['textfield2']
    Cholestoral = request.form['textfield3']
    fbs = request.form['textfield4']
    electrocardiographic = request.form['select2']
    m_heart_rate = request.form['textfield5']
    Exercise_induced_angina = request.form['radiobutton8']
    Oldpeak = request.form['textfield6']
    Slope = request.form['select3']
    major_vessels = request.form['select4']
    Thal = request.form['select5']
    val=(age, Gender, cp, rbp, Cholestoral, fbs, electrocardiographic, m_heart_rate, Exercise_induced_angina, Oldpeak, Slope, major_vessels, Thal)
    result = predict(val)
    print(result)
    return render_template('user/view_result.html',res=result)

@obj.route('/d_pre')
def d_pre():
    return render_template('user/diet_pre.html')

@obj.route('/diet_pre_post', methods=['POST'])
def diet_pre_post():
    age = request.form['textfield']
    gender = request.form['radiobutton']
    height = request.form['textfield2']
    initial_weight = request.form['textfield3']
    final_weight = request.form['textfield4']
    val=(age, gender, height, initial_weight, final_weight)
    result = predict_diet(val)
    print(result)
    return render_template('user/view_diet_result.html',res=result)


obj.run(debug=True)
